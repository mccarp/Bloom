# Bloom
A hunting and influencing mudlet system for Lusternia, Age of Ascension.

It is a standalone package, other than requiring the IRE mudlet mapper (mmp) to be installed. If you don't have it, you can find it here: https://github.com/IRE-Mudlet-Mapping/ire-mapping-script

The zip version is the easiest to download, but you can also download the xml version by navigating to the raw version of it, and right clicking->save as.

Once installed, BLOOM or BLOOM HELP will bring up additional information about the system's commands.

A big thank you to Demonnic (Damian Monogue) for his demonwalker code which I adapted for use in this system. You can take a look at some of his other awesome projects over at https://github.com/demonnic
